package com.senai.javafx.controllers.LadoCliente;

import com.senai.javafx.controllers.LadoAdministrador.CadastroJogosController;
import com.senai.javafx.entidades.Carrinho;
import com.senai.javafx.entidades.Compra;
import com.senai.javafx.entidades.Cpf;
import com.senai.javafx.entidades.FormaPagamento;
import com.senai.javafx.entidades.GerenciamentoJanela;
import com.senai.javafx.entidades.RegistroCompras;
import com.senai.javafx.entidades.Sessao;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;

import java.text.NumberFormat;
import java.util.Locale;

public class PagamentoController {

    private static final NumberFormat FORMATO_PRECO =
            NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));

    @FXML
    private ToggleGroup grupoPagamento;

    @FXML
    private ToggleButton tglPix, tglCartao, tglDinheiro;

    @FXML
    private VBox boxCpf;

    @FXML
    private TextField txtCpf;

    @FXML
    private Label lblItens, lblSubtotal, lblRotuloDesconto, lblDesconto, lblTotal;

    @FXML
    private Button btnConfirmar;

    @FXML
    public void initialize() {
        configurarOpcao(tglPix, FormaPagamento.PIX);
        configurarOpcao(tglCartao, FormaPagamento.CARTAO);
        configurarOpcao(tglDinheiro, FormaPagamento.DINHEIRO);

        // Clicar na opção já marcada não pode deixar o grupo sem nenhuma escolha
        grupoPagamento.selectedToggleProperty().addListener((obs, antigo, novo) -> {
            if (novo == null && antigo != null) {
                antigo.setSelected(true);
                return;
            }
            aoEscolherForma();
        });

        // CPF: só números, formatado como 000.000.000-00 enquanto digita
        txtCpf.setTextFormatter(new TextFormatter<String>(mudanca -> {
            if (!mudanca.isContentChange()) {
                return mudanca;
            }
            String digitos = Cpf.somenteDigitos(mudanca.getControlNewText());
            if (digitos.length() > 11) {
                return null;
            }
            String formatado = Cpf.formatar(digitos);
            mudanca.setRange(0, mudanca.getControlText().length());
            mudanca.setText(formatado);
            mudanca.selectRange(formatado.length(), formatado.length());
            return mudanca;
        }));

        lblItens.setText(Carrinho.getResumoItens());
        atualizarResumo(null);

        // Sem itens não há o que pagar: volta para a loja
        if (Carrinho.isVazio()) {
            Platform.runLater(this::voltarParaLoja);
        }
    }

    private void configurarOpcao(ToggleButton botao, FormaPagamento forma) {
        botao.setUserData(forma);
        botao.setText(forma.getRotulo() + "\n" + forma.getDescricaoDesconto());
    }

    private FormaPagamento formaSelecionada() {
        Toggle escolhido = grupoPagamento.getSelectedToggle();
        return escolhido == null ? null : (FormaPagamento) escolhido.getUserData();
    }

    private void aoEscolherForma() {
        FormaPagamento forma = formaSelecionada();
        boolean escolheu = forma != null;

        // O CPF (chave Pix) só é pedido depois que a forma de pagamento foi escolhida
        boxCpf.setVisible(escolheu);
        boxCpf.setManaged(escolheu);
        btnConfirmar.setDisable(!escolheu);

        atualizarResumo(forma);

        if (escolheu) {
            Platform.runLater(txtCpf::requestFocus);
        }
    }

    private void atualizarResumo(FormaPagamento forma) {
        double subtotal = Carrinho.getSubtotal();
        lblSubtotal.setText(FORMATO_PRECO.format(subtotal));

        if (forma == null) {
            lblRotuloDesconto.setText("Desconto");
            lblDesconto.setText("Escolha a forma de pagamento");
            lblTotal.setText(FORMATO_PRECO.format(subtotal));
            return;
        }

        if (forma.getPercentualDesconto() == 0) {
            lblRotuloDesconto.setText("Desconto");
            lblDesconto.setText("Sem desconto");
        } else {
            lblRotuloDesconto.setText("Desconto " + forma.getRotulo() + " (" + forma.getPercentualDesconto() + "%)");
            lblDesconto.setText("- " + FORMATO_PRECO.format(forma.calcularDesconto(subtotal)));
        }
        lblTotal.setText(FORMATO_PRECO.format(forma.calcularTotal(subtotal)));
    }

    @FXML
    private void confirmarPagamento(ActionEvent event) {
        FormaPagamento forma = formaSelecionada();
        if (forma == null) {
            GerenciamentoJanela.exibirAlerta("Atenção", "Escolha a forma de pagamento.",
                    GerenciamentoJanela.TipoAlerta.ALERTA);
            return;
        }
        if (!Cpf.valido(txtCpf.getText())) {
            GerenciamentoJanela.exibirAlerta("Atenção",
                    "Informe um CPF válido para usar como chave Pix.",
                    GerenciamentoJanela.TipoAlerta.ALERTA);
            txtCpf.requestFocus();
            return;
        }

        try {
            Compra compra = RegistroCompras.finalizarPagamento(
                    Sessao.getUsuarioLogado(), txtCpf.getText(), forma,
                    CadastroJogosController.jogosSalvos::contains);

            GerenciamentoJanela.exibirAlerta("Pagamento realizado",
                    "Obrigado! Sua compra nº " + compra.getNumero() + " ("
                            + FORMATO_PRECO.format(compra.getTotal()) + " em " + forma.getRotulo()
                            + ") foi enviada para a aprovação do administrador.",
                    GerenciamentoJanela.TipoAlerta.SUCESSO);
            voltarParaLoja();

        } catch (IllegalStateException e) {
            // Normalmente estoque que acabou enquanto o cliente pagava: nada foi cobrado.
            // Ajusta o carrinho e leva o cliente de volta para conferir.
            Carrinho.ajustarAoEstoque(CadastroJogosController.jogosSalvos::contains);
            GerenciamentoJanela.exibirAlerta("Não foi possível concluir", e.getMessage(),
                    GerenciamentoJanela.TipoAlerta.ALERTA);
            GerenciamentoJanela.abrirJanela("/com/senai/javafx/carrinho.fxml", "Nexus Store - Carrinho");
        }
    }

    @FXML
    private void voltarCarrinho(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/carrinho.fxml", "Nexus Store - Carrinho");
    }

    private void voltarParaLoja() {
        if (!GerenciamentoJanela.restaurarTelaGuardada("Nexus Store - Página inicial")) {
            GerenciamentoJanela.abrirJanela("/com/senai/javafx/telaInicial.fxml", "Nexus Store - Página inicial");
        }
    }
}
