package com.senai.javafx.controllers.LadoAdministrador;

import com.senai.javafx.entidades.GerenciamentoJanela;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class MenuController {

    // Controller do menu administrativo


    @FXML
    private void consultarClientes(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/consultaClientes.fxml", "Consultar Clientes");
    }

    @FXML
    private void cadastroJogos(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/cadastroJogos.fxml", "Cadastrar Jogo");
    }

    @FXML
    private void cadastroCategoria(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/cadastroCategoria.fxml", "Cadastrar Categoria");
    }

    @FXML
    private void consultarJogos(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/consultarJogos.fxml", "Consultar Jogos");
    }

    @FXML
    private void alternarConta(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/opcaoUser.fxml", "Nexus Store - Boas-vindas");
    }

    @FXML
    private void voltarPaginaInicial(ActionEvent event) {
        GerenciamentoJanela.abrirJanela("/com/senai/javafx/telaInicial.fxml", "Nexus Store");

    }

}